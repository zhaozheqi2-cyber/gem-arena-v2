# 六家循环赛：原局面续赛

原先安全停止的 26 局均从原局面继续；已有 1 局结束，25 局仍待续。其余 724 局保持原结果。

按种子重建并逐步重放原日志，逐帧校对第 400 手的市场、库存、贵族及暗牌；剩余牌堆顺序由原始种子和行动完整恢复。六份选手程序均不产生持久 memory，恢复为原来的 None。先后手、绝对回合编号、冻结代码、每回合合计 3 秒和 8 局并发保持不变。唯一赛制变化是从续赛开始 max_turns=0，取消人工终局。

**尚未结束的比赛不计平局、不发半分。** 每局再运行 400 手后保存待续检查点；这只是执行批次，不是新终局规则。重复状态包含私有牌堆、暗牌、筹码、阶段和行动方，但去掉绝对回合与决策计数。对有计时搜索的程序，重复状态并不证明下一次必然选相同动作。

| 排名 | 选手 | 胜 | 平 | 负 | 待续 | 已获积分 | 最高可能积分 |
|---:|---|---:|---:|---:|---:|---:|---:|
| 1 | Sol | 207 | 0 | 42 | 1 | 207 | 208 |
| 2 | Astra | 201 | 0 | 46 | 3 | 201 | 204 |
| 3 | Claude | 175 | 0 | 66 | 9 | 175 | 184 |
| 4 | Gemini | 79 | 0 | 170 | 1 | 79 | 80 |
| 5 | Qwen | 62 | 0 | 177 | 11 | 62 | 73 |
| 6 | DeepSeek | 1 | 0 | 224 | 25 | 1 | 26 |

名次是否已不受待续局结果影响：是。

## 26 局续赛明细

| 对阵 | 原局号 | 当前分数 | 原分数 | 当前手数 | 状态 | 重复局面次数 | 回放 |
|---|---:|---|---|---:|---|---:|---|
| Astra vs DeepSeek | 2 | [2, 0] | [2, 0] | 800 | pending_checkpoint | 399 | [续赛回放](05-astra-vs-deepseek/game_02.html) |
| Astra vs DeepSeek | 12 | [4, 0] | [4, 0] | 800 | pending_checkpoint | 399 | [续赛回放](05-astra-vs-deepseek/game_12.html) |
| Astra vs DeepSeek | 15 | [4, 0] | [4, 0] | 800 | pending_checkpoint | 399 | [续赛回放](05-astra-vs-deepseek/game_15.html) |
| Sol vs DeepSeek | 45 | [4, 0] | [4, 0] | 800 | pending_checkpoint | 399 | [续赛回放](09-sol-vs-deepseek/game_45.html) |
| Claude vs DeepSeek | 2 | [1, 1] | [1, 1] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_02.html) |
| Claude vs DeepSeek | 8 | [2, 0] | [2, 0] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_08.html) |
| Claude vs DeepSeek | 27 | [5, 0] | [5, 0] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_27.html) |
| Claude vs DeepSeek | 33 | [15, 6] | [5, 4] | 440 | target | 20 | [续赛回放](12-claude-vs-deepseek/game_33.html) |
| Claude vs DeepSeek | 34 | [5, 3] | [5, 3] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_34.html) |
| Claude vs DeepSeek | 35 | [2, 0] | [2, 0] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_35.html) |
| Claude vs DeepSeek | 38 | [1, 3] | [1, 3] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_38.html) |
| Claude vs DeepSeek | 39 | [5, 3] | [5, 3] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_39.html) |
| Claude vs DeepSeek | 40 | [6, 0] | [4, 0] | 800 | pending_checkpoint | 381 | [续赛回放](12-claude-vs-deepseek/game_40.html) |
| Claude vs DeepSeek | 50 | [3, 2] | [3, 2] | 800 | pending_checkpoint | 399 | [续赛回放](12-claude-vs-deepseek/game_50.html) |
| Gemini vs DeepSeek | 33 | [1, 0] | [1, 0] | 800 | pending_checkpoint | 399 | [续赛回放](14-gemini-vs-deepseek/game_33.html) |
| Qwen vs DeepSeek | 11 | [5, 2] | [5, 2] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_11.html) |
| Qwen vs DeepSeek | 12 | [5, 2] | [5, 2] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_12.html) |
| Qwen vs DeepSeek | 13 | [3, 0] | [3, 0] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_13.html) |
| Qwen vs DeepSeek | 14 | [3, 0] | [3, 0] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_14.html) |
| Qwen vs DeepSeek | 33 | [1, 0] | [1, 0] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_33.html) |
| Qwen vs DeepSeek | 34 | [1, 2] | [1, 2] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_34.html) |
| Qwen vs DeepSeek | 41 | [3, 1] | [3, 1] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_41.html) |
| Qwen vs DeepSeek | 42 | [1, 1] | [1, 1] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_42.html) |
| Qwen vs DeepSeek | 43 | [7, 4] | [7, 4] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_43.html) |
| Qwen vs DeepSeek | 44 | [1, 0] | [1, 0] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_44.html) |
| Qwen vs DeepSeek | 45 | [2, 0] | [2, 0] | 800 | pending_checkpoint | 399 | [续赛回放](15-qwen-vs-deepseek/game_45.html) |

原始 750 局报告与回放保留在相邻的 v2-six-way-750 文件夹。续赛回放从原第 400 手开始；所有新增决定均已独立重放验证。checkpoint.json 保存私有完整现场，供裁判继续，不能在比赛未结束时发给选手。
