# 六家 v2 循环赛：750 局排名

15 组交锋，每组 50 局；每位选手 250 局、先后手各 125 局。所有组合共用 25 组新牌局种子，每个种子交换先手。

胜 1 分、平 0.5 分、负 0 分。总分相同则比较同分选手间的小循环积分，仍相同则并列。未用耗时或平均分替代胜负排名。

| 排名 | 选手 | 胜 | 平 | 负 | 积分 | 平均得分 | 故障 | 平均每次调用 ms |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | Sol | 207 | 1 | 42 | 207.5 | 15.168 | 0 | 327.325 |
| 2 | Astra | 201 | 3 | 46 | 202.5 | 14.736 | 1 | 315.167 |
| 3 | Claude | 174 | 10 | 66 | 179 | 13.52 | 0 | 549.268 |
| 4 | Gemini | 79 | 1 | 170 | 79.5 | 8.672 | 0 | 234.091 |
| 5 | Qwen | 62 | 11 | 177 | 67.5 | 9.016 | 0 | 219.662 |
| 6 | DeepSeek／肥鱼 | 1 | 26 | 223 | 14 | 2.292 | 1 | 214.061 |

## 赛后看点

- **Sol／Prism II 夺冠，领先 Astra 5 分。** 207 胜、1 平、42 负，积分 207.5；全轮零运行故障。
- **Astra 赢了单挑，总榜冠军仍归 Sol。** Astra 对 Sol 是 26∶24；对 Claude，Sol 拿下 34 胜，Astra 拿下 28 胜。对肥鱼两人分别是 49 胜 1 平、47 胜 3 平。由这三组交锋的积分差，恰好得到 Sol 总榜领先 5 分；两人对 Gemini、Qwen 均为 50∶0。
- **Claude 是这轮的贵族社交达人。** 共 188 次贵族来访、购牌 3380 次，均为六家最高，总榜第三。这是行动统计，不是对策略收益的因果解释。
- **肥鱼唯一一胜，靠的是账本更薄。** 对 Qwen 第 23 局双方同为 16 分；肥鱼购买 7 张发展牌，Qwen 14 张，按同分规则肥鱼胜。其余场次累计 26 平、223 负。[看这局回放](15-qwen-vs-deepseek/game_23.html)。
- 全轮 26 场平局均为 400 回合安全停止，且都涉及肥鱼；没有正常达标后完全同分同牌数的平局。两次超时分别是 Astra 对 Sol 第 3 局、肥鱼对 Claude 第 1 局，均在 discard 阶段，已按规则判负。

## 两两战绩

比分为表中前者胜局∶后者胜局，另列平局。

| 对阵 | 胜局 | 平局 | 全部回放 |
| --- | ---: | ---: | --- |
| Astra vs Sol | 26∶24 | 0 | [50 局](01-astra-vs-sol/index.html) |
| Astra vs Claude | 28∶22 | 0 | [50 局](02-astra-vs-claude/index.html) |
| Astra vs Gemini | 50∶0 | 0 | [50 局](03-astra-vs-gemini/index.html) |
| Astra vs Qwen | 50∶0 | 0 | [50 局](04-astra-vs-qwen/index.html) |
| Astra vs DeepSeek | 47∶0 | 3 | [50 局](05-astra-vs-deepseek/index.html) |
| Sol vs Claude | 34∶16 | 0 | [50 局](06-sol-vs-claude/index.html) |
| Sol vs Gemini | 50∶0 | 0 | [50 局](07-sol-vs-gemini/index.html) |
| Sol vs Qwen | 50∶0 | 0 | [50 局](08-sol-vs-qwen/index.html) |
| Sol vs DeepSeek | 49∶0 | 1 | [50 局](09-sol-vs-deepseek/index.html) |
| Claude vs Gemini | 48∶2 | 0 | [50 局](10-claude-vs-gemini/index.html) |
| Claude vs Qwen | 48∶2 | 0 | [50 局](11-claude-vs-qwen/index.html) |
| Claude vs DeepSeek | 40∶0 | 10 | [50 局](12-claude-vs-deepseek/index.html) |
| Gemini vs Qwen | 28∶22 | 0 | [50 局](13-gemini-vs-qwen/index.html) |
| Gemini vs DeepSeek | 49∶0 | 1 | [50 局](14-gemini-vs-deepseek/index.html) |
| Qwen vs DeepSeek | 38∶1 | 11 | [50 局](15-qwen-vs-deepseek/index.html) |

## 执行与复核

全部 750 局已由原始 v2 验证器从种子逐次重放，核对动作、辅助阶段、状态、座次、分数和结果。六份参赛源码、原始裁判及牌表指纹复核一致。

- 规则 gem-arena-2.0，每回合共享 3 秒，8 局并行，Python 3.12.14。
- local 可信模式，未启用容器或 CPU／内存硬隔离；搜索按时钟截止的选手，其搜索深度和行动可能随并行负载变化。
- 默认 400 个已完成回合安全上限，触顶记平局。本轮安全停止 26 局；运行／协议故障总数 2。
- 参赛版本仅包含封存的 Astra／Codex、Sol／Prism II、Claude、Gemini、Qwen、DeepSeek／肥鱼；Perplexity 按主办方要求退出。
- [总汇总](league_summary.json)、[排名 CSV](ranking.csv)、[750 局 CSV](all_games.csv)、[环境与冻结指纹](manifest.json)。各对阵目录包含全部 JSON 与离线 HTML 回放。
- 验证命令：在原项目 splendor-arena-v2 目录执行 `python -m arena.verify <对阵目录绝对路径>`。验证器重放棋盘，不重新运行计时搜索。
- 这是这些提交版本在本规则、本批牌局和本执行环境下的成绩，不合并上一轮简化规则战绩。

## 回放精选

- [Astra vs Sol · 第 7 局](01-astra-vs-sol/game_07.html)：15∶8，Astra 胜。
- [Astra vs Sol · 第 13 局](01-astra-vs-sol/game_13.html)：7∶17，Sol 胜。
- [Astra vs Claude · 第 21 局](02-astra-vs-claude/game_21.html)：16∶2，Astra 胜。
- [Astra vs Claude · 第 7 局](02-astra-vs-claude/game_07.html)：14∶21，Claude 胜。
- [Astra vs Gemini · 第 39 局](03-astra-vs-gemini/game_39.html)：17∶1，Astra 胜。
- [Astra vs Qwen · 第 41 局](04-astra-vs-qwen/game_41.html)：16∶1，Astra 胜。
- [Astra vs DeepSeek · 第 16 局](05-astra-vs-deepseek/game_16.html)：20∶0，Astra 胜。
- [Sol vs Claude · 第 19 局](06-sol-vs-claude/game_19.html)：18∶2，Sol 胜。
- [Sol vs Claude · 第 29 局](06-sol-vs-claude/game_29.html)：10∶17，Claude 胜。
- [Sol vs Gemini · 第 7 局](07-sol-vs-gemini/game_07.html)：17∶0，Sol 胜。
- [Sol vs Qwen · 第 1 局](08-sol-vs-qwen/game_01.html)：17∶3，Sol 胜。
- [Sol vs DeepSeek · 第 46 局](09-sol-vs-deepseek/game_46.html)：22∶0，Sol 胜。
- [Claude vs Gemini · 第 31 局](10-claude-vs-gemini/game_31.html)：19∶1，Claude 胜。
- [Claude vs Gemini · 第 50 局](10-claude-vs-gemini/game_50.html)：15∶19，Gemini 胜。
- [Claude vs Qwen · 第 43 局](11-claude-vs-qwen/game_43.html)：15∶1，Claude 胜。
- [Claude vs Qwen · 第 24 局](11-claude-vs-qwen/game_24.html)：8∶17，Qwen 胜。
- [Claude vs DeepSeek · 第 14 局](12-claude-vs-deepseek/game_14.html)：20∶0，Claude 胜。
- [Gemini vs Qwen · 第 32 局](13-gemini-vs-qwen/game_32.html)：17∶7，Gemini 胜。
- [Gemini vs Qwen · 第 44 局](13-gemini-vs-qwen/game_44.html)：4∶15，Qwen 胜。
- [Gemini vs DeepSeek · 第 45 局](14-gemini-vs-deepseek/game_45.html)：22∶2，Gemini 胜。
- [Qwen vs DeepSeek · 第 2 局](15-qwen-vs-deepseek/game_02.html)：22∶3，Qwen 胜。
- [Qwen vs DeepSeek · 第 23 局](15-qwen-vs-deepseek/game_23.html)：16∶16，DeepSeek 胜。

## 汇总恢复说明

中央进度文件在第 100 局后替换时遇到 Windows 拒绝访问错误；后台进程池继续完成全部 750 个任务，逐局 JSON 与 HTML 均已保存。最终汇总直接读取这 750 份原始日志重建，再由未修改的 v2 验证器逐局核对。没有修改参赛代码、种子、规则或赛果，也没有重跑任何一局。详见 verification.json。
